const { Sequelize, DataTypes } = require('sequelize');

// データベースの接続
const sequelize = new Sequelize({
  dialect: 'sqlite',
  storage: 'database.sqlite'
});

// ルーム名テーブルの定義
const Room = sequelize.define('Room', {
  name: {
    type: DataTypes.STRING,
    unique: true,
    allowNull: false
  }
});

// ルーム名データの挿入
(async () => {
  await sequelize.sync();

  await Room.bulkCreate([
    { name: 'Room1' },
    { name: 'Room2' },
    { name: 'Room3' }
  ]);

  console.log('Test rooms inserted');
})();
