const express = require('express');
const path = require('path');
const { Sequelize, DataTypes } = require('sequelize');
const bcrypt = require('bcrypt');

const app = express();
const port = 3000;

// データベースの接続
const sequelize = new Sequelize({
  dialect: 'sqlite',
  storage: 'database.sqlite'
});

// ユーザーテーブルとルーム名テーブルの定義
const User = sequelize.define('User', {
  id: {
    type: DataTypes.STRING,
    primaryKey: true,
    allowNull: false
  },
  password: {
    type: DataTypes.STRING,
    allowNull: false
  }
});

const Room = sequelize.define('Room', {
  name: {
    type: DataTypes.STRING,
    unique: true,
    allowNull: false
  },
  createdAt: {
    type: DataTypes.DATE,
    allowNull: false
  },
  pass: {
    type: DataTypes.STRING,
    allowNull: false
  }
});

app.use(express.static(path.join(__dirname)));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// ログインエンドポイント
app.post('/login', async (req, res) => {
  const { id, password } = req.body;
  const user = await User.findByPk(id);
  if (user && await bcrypt.compare(password, user.password)) {
    res.redirect('/search.html'); // ログイン成功後にルーム検索ページにリダイレクト
  } else {
    res.status(401).send('Invalid ID or password');
  }
});

// ルーム検索エンドポイント
app.get('/search-room', async (req, res) => {
  const roomName = req.query.name;
  const room = await Room.findOne({ where: { name: roomName } });
  if (room) {
    // ルーム名、作成日時、パスを表示
    res.send(`Room found: ${room.name} Password: ${room.pass}`);
  } else {
    res.status(404).send('Room not found');
  }
});

// サーバーの起動
app.listen(port, () => {
  console.log(`Server is running on http://localhost:${port}`);
});
