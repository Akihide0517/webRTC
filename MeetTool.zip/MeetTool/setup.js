const { Sequelize, DataTypes } = require('sequelize');
const bcrypt = require('bcrypt');

// データベースの接続
const sequelize = new Sequelize({
  dialect: 'sqlite',
  storage: 'database.sqlite'
});

// ユーザーテーブルの定義
const User = sequelize.define('User', {
  id: {
    type: DataTypes.STRING,
    primaryKey: true,
    allowNull: false
  },
  password: {
    type: DataTypes.STRING,
    allowNull: false
  }
});

// ルーム名テーブルの定義（passカラムを追加）
const Room = sequelize.define('Room', {
  name: {
    type: DataTypes.STRING,
    unique: true,
    allowNull: false
  },
  createdAt: {
    type: DataTypes.DATE,
    allowNull: false
  },
  pass: {
    type: DataTypes.STRING,
    allowNull: false
  }
});

// テーブルの作成
(async () => {
  await sequelize.sync({ force: true });
  console.log('Tables created!');

  // デモユーザーの作成（パスワードはプレーンテキストで指定）
  const saltRounds = 10;
  const hashedPassword = await bcrypt.hash('password123', saltRounds);

  await User.create({
    id: 'testuser',
    password: hashedPassword
  });

  // デモルームの作成
  await Room.bulkCreate([
    { name: 'Room1', createdAt: new Date(), pass: 'pass1' },
    { name: 'Room2', createdAt: new Date(), pass: 'pass2' },
    { name: 'Room3', createdAt: new Date(), pass: 'pass3' }
  ]);
})();
