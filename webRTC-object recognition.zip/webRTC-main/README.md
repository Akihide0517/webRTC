**このサンプルはhttps通信を利用して、ml5.jsを使って通信相手のカメラの物体検出を行うことができます**

*なお本コードは完動させるためにめちゃくちゃな改造を施した後にGPTにリコーディングさせています。

### **多分インストールは必要ないと思いますが、一応**

npm i ml5

### **Node.jsを使ってhttpsサーバーを気軽に立てる方法**

https://qiita.com/tkyko13/items/1871d906736ac88a1f35

### **参考文献(この通りやっても動きません)**

元ネタ
https://qiita.com/21emon/items/b695d7a01d2c9da23b67

応用例
https://qiita.com/3yaka4/items/53670880a74b21a2d7ce

### **ml5が使えるということはできるかもしれないこと**

メガネをかけさせる
https://qiita.com/PmanRabbit/items/7b0c70ce7e77aed146e3

感情分析
https://qiita.com/kolife/items/0a76754077085f81f91a

音声認識
https://qiita.com/canonno/items/fb3b2f10937d0ba80cb4

特定箇所のモザイク加工
https://qiita.com/kokushin/items/a2b00a8ecf1edccb8199

**多分動くとは思いますが、もし動かなければ、ローカルファイルにライブラリをダウンロードして読み込む方法をお試し下さい**
